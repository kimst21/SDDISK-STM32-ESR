/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : SD 카드 파일 작업 프로그램
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"  // FATFS 파일 시스템 라이브러리
#include "spi.h"    // SPI 통신 설정
#include "usb_device.h" // USB CDC 통신 설정
#include "gpio.h"   // GPIO 설정

/* USER CODE BEGIN Includes */
#include "usbd_cdc_if.h"  // USB CDC 인터페이스 라이브러리
#include <stdio.h>        // 표준 입출력 라이브러리
/* USER CODE END Includes */

/* USER CODE BEGIN PV */
// SD 카드 파일 작업 관련 변수
FATFS fs;              // 파일 시스템 객체
FATFS *pfs;            // 파일 시스템 포인터
FIL fil;               // 파일 객체
FRESULT fres;          // 작업 결과
DWORD fre_clust;       // 여유 클러스터 수
uint32_t total, free_space;  // 전체 용량 및 여유 용량
char buffer[100];      // 읽기/쓰기 버퍼
uint16_t i = 0;        // 루프 인덱스
/* USER CODE END PV */

int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();  // HAL 라이브러리 초기화 (시스템 기본 설정)

  /* Configure the system clock */
  SystemClock_Config(); // 시스템 클럭 설정

  /* Initialize all configured peripherals */
  MX_GPIO_Init();       // GPIO 초기화
  MX_SPI1_Init();       // SPI 초기화 (SD 카드 통신용)
  MX_FATFS_Init();      // FATFS 초기화
  MX_USB_DEVICE_Init(); // USB CDC 초기화 (PC 통신용)

  /* USER CODE BEGIN 2 */

  /* 1. SD 카드 마운트 */
  if(f_mount(&fs, "", 0) != FR_OK) {
    Error_Handler();  // 마운트 실패 시 에러 처리
  }

  /* 2. 파일 열기 (쓰기) */
  if(f_open(&fil, "sdcard.txt", FA_OPEN_ALWAYS | FA_READ | FA_WRITE) != FR_OK) {
    Error_Handler();  // 파일 열기 실패 시 에러 처리
  }

  /* 3. 여유 공간 확인 */
  if(f_getfree("", &fre_clust, &pfs) != FR_OK) {
    Error_Handler();  // 여유 공간 확인 실패 시 에러 처리
  }

  // 전체 용량 및 여유 용량 계산
  total = (uint32_t)((pfs->n_fatent - 2) * pfs->csize * 0.5);  // 전체 용량 (KB)
  free_space = (uint32_t)(fre_clust * pfs->csize * 0.5);       // 여유 용량 (KB)

  // 여유 공간이 1KB 미만인 경우 에러 처리
  if(free_space < 1) {
    Error_Handler();
  }

  /* 4. 파일에 텍스트 쓰기 */
  f_puts("SD Card test - All-In-One ESR Board\n", &fil);

  /* 5. 파일 닫기 */
  if(f_close(&fil) != FR_OK) {
    Error_Handler();  // 파일 닫기 실패 시 에러 처리
  }

  /* 6. 파일 열기 (읽기) */
  HAL_Delay(1000);  // 읽기 작업 전 1초 대기
  if(f_open(&fil, "sdcard.txt", FA_READ) != FR_OK) {
    Error_Handler();  // 파일 열기 실패 시 에러 처리
  }

  /* 7. 파일에서 데이터 읽기 */
  while(f_gets(buffer, sizeof(buffer), &fil)) {
    printf("%s", buffer);  // USB CDC를 통해 PC로 출력
  }

  /* 8. 파일 닫기 */
  if(f_close(&fil) != FR_OK) {
    Error_Handler();  // 파일 닫기 실패 시 에러 처리
  }

  /* 9. SD 카드 언마운트 */
  if(f_mount(NULL, "", 1) != FR_OK) {
    Error_Handler();  // 언마운트 실패 시 에러 처리
  }

  /* USER CODE END 2 */

  /* Infinite loop */
  while (1) {
    // 시스템 대기 상태
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
